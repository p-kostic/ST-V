﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STV1
{
    public abstract class Item
    {
        public abstract void UseItem(Player player);
        public abstract string ItemType();
    }
}
